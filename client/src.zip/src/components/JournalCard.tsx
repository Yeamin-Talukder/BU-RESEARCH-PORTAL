import React from 'react'

function JournalCard() {
  return (
    <div>JournalCard</div>
  )
}

export default JournalCard